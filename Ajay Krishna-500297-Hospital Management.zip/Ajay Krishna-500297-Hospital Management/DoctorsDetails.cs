﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement
{
    class DoctorsDetails
    {
        InPatient InP = new InPatient();
        List<DoctorsDetails> DocList = new List<DoctorsDetails>();
        public DoctorsDetails()
        {
        }

        public string DoctorName
        {
            get;
            set;
        }

        public int DoctorId;

        public string Speciality
        {
            get;
            set;
        }

        public string IsAvailable
        {
            get;
            set;
        }
        public DoctorsDetails(string docname, string spec, string isaval, int docId)
        {
            DoctorName = docname;
            Speciality = spec;
            IsAvailable = isaval;
            DoctorId = docId;
        }
        public void AddDoctorDetails()
        {
            Random r = new Random();
            DoctorId = r.Next(1, 99);
            Console.WriteLine("Enter the Doctor's Name : ");
            DoctorName = Console.ReadLine();
            int valid = InP.IsValid(DoctorName);
            if (valid == 1)
            {
                Console.WriteLine("Enter the Speciality : ");
                Speciality = Console.ReadLine();
                Console.WriteLine("available (yes/no) : ");
                IsAvailable = Console.ReadLine();
                DocList.Add(new DoctorsDetails(DoctorName, Speciality, IsAvailable, DoctorId));
                Console.WriteLine("Id is {0}", DoctorId);
                Console.WriteLine("Details submitted ");
            }
            else
            {
                Console.WriteLine("invalid input");
            }
        }

        public void GetDoctorDetails()
        {
            try
            {
                int count = 0, docid;
                Console.WriteLine("Enter the Doctor's-ID");
                docid = int.Parse(Console.ReadLine());
                foreach (DoctorsDetails dd in DocList)
                {
                    if (docid == dd.DoctorId)
                    {
                        Console.WriteLine("Name: " + DoctorName);
                        Console.WriteLine("Speciality: " + Speciality);
                        Console.WriteLine("Availabilty: " + IsAvailable);
                        Console.WriteLine("ID: " + DoctorId);
                        count++;
                        break;
                    }
                }
                if (count == 0)
                {
                    Console.WriteLine("Invalid id");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void Doctoravailability()
        {
            if (this.IsAvailable == "yes")
            {
                Console.WriteLine(" Available ");
            }
            else
            {
                Console.WriteLine(" Not Available");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement
{
    class MainClass
    {
        enum Mainmethod
        {
            DoctorDetails = 1, InPatient = 2, OutPatient = 3, Exit = 4
        }

        enum DocDetails
        {
            AddDoctorDetails = 1, GetDoctorDetails = 2, Exit = 3
        }

        enum InPatDetails
        {
            AddPatientDetails = 1, GetPatientDetails = 2, RemovePatientDetails = 3, Exit = 4
        }
        enum OutPatDetails
        {
            AddPatientDetails = 1, GetPatientDetails = 2, RemovePatientDetails = 3, GetBill = 4, getPatientSummary = 5, Exit = 6
        }
        static void Main(string[] args)
        {

            DoctorsDetails docDet = new DoctorsDetails();
            InPatient inPat = new InPatient();
            OutPatient outPat = new OutPatient();
            Console.ForegroundColor = ConsoleColor.DarkCyan;
            Console.WriteLine("Welcome to Hospital Management System");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Select from the following");
            Console.ResetColor();
            int x = 0, choice1;
            while (x == 0)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("1. Doctor Details\n2. In Patient\n3. Out Patient\n4. Exit");
                Console.ResetColor();
                while (true)
                {
                    if (int.TryParse(Console.ReadLine(), out choice1))
                    {
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Enter the valid number");
                        Console.ResetColor();
                    }
                }
                switch ((Mainmethod)choice1)
                {
                    case Mainmethod.DoctorDetails:
                        {
                            int y = 0, ch;
                            while (y == 0)
                            {
                                Console.WriteLine("\n");
                                Console.WriteLine("1. Add Doctor Details\n2. Get Doctor Details\n3. Exit");
                                while (true)
                                {
                                    try
                                    {
                                        ch = int.Parse(Console.ReadLine());
                                        break;
                                    }
                                    catch (Exception)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("enter valid choice");
                                        Console.ResetColor();
                                    }
                                }

                                switch ((DocDetails)ch)
                                {
                                    case DocDetails.AddDoctorDetails:
                                        docDet.AddDoctorDetails();
                                        break;
                                    case DocDetails.GetDoctorDetails:

                                        docDet.GetDoctorDetails();
                                        break;
                                    case DocDetails.Exit:
                                        y = 1;
                                        break;
                                }
                            }
                        }
                        break;
                    case Mainmethod.InPatient:
                        {
                            int y = 0, choice2;
                            while (y == 0)
                            {
                                Console.WriteLine("\n");
                                Console.WriteLine("1.Add Patient Details\n2. Get Patient Details\n3. Remove Patient\n4. Exit");
                                while (true)
                                {
                                    try
                                    {
                                        choice2 = int.Parse(Console.ReadLine());
                                        break;
                                    }
                                    catch (Exception)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("enter valid choice");
                                        Console.ResetColor();
                                    }
                                }

                                switch ((InPatDetails)choice2)
                                {
                                    case InPatDetails.AddPatientDetails:
                                        inPat.AddPatientDetails();
                                        break;
                                    case InPatDetails.GetPatientDetails:
                                        inPat.GetPatientDetails();
                                        break;
                                    case InPatDetails.RemovePatientDetails:
                                        inPat.RemovePatient();
                                        break;
                                    case InPatDetails.Exit:
                                        y = 1;
                                        break;
                                }
                            }
                        }
                        break;
                    case Mainmethod.OutPatient:
                        int endLoop1 = 1, choice;
                        while (endLoop1 == 1)
                        {
                            Console.WriteLine("\n");
                            Console.WriteLine("1. Add Patient Details\n2. Get Patient Details\n3. Remove Patient\n4. Get Bill\n 5. Get Patient Summary \n 6. Exit");
                            while (true)
                            {
                                try
                                {
                                    choice = int.Parse(Console.ReadLine());
                                    break;
                                }
                                catch (Exception)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("enter valid choice");
                                    Console.ResetColor();
                                }
                            }
                            switch ((OutPatDetails)choice)
                            {
                                case OutPatDetails.AddPatientDetails:
                                    outPat.AddPatientDetails();
                                    break;
                                case OutPatDetails.GetPatientDetails:
                                    outPat.GetPatientDetails();
                                    break;
                                case OutPatDetails.RemovePatientDetails:
                                    outPat.RemovePatient();
                                    break;
                                case OutPatDetails.GetBill:
                                    outPat.GetBill();
                                    break;
                                case OutPatDetails.getPatientSummary:
                                    outPat.getPatientSummary();
                                    break;
                                case OutPatDetails.Exit:
                                    endLoop1 = -1;
                                    break;
                            }
                        }
                        break;
                    case Mainmethod.Exit:
                        x = 1;
                        break;
                }
            }
        }
    }
}



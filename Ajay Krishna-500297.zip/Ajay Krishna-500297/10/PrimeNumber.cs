﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumber
{
    class PrimeNumber
    {
        static void Main(string[] args)
        {
            int number;
            Console.WriteLine("Enter a number to check whether it is prime or not");
            number = int.Parse(Console.ReadLine());
            test(number);
            Console.ReadKey();
        }

        private static void test(int number)
        {
            bool trueorfalse = isPrimeNumber(number);
            if (trueorfalse == true)
                Console.WriteLine($"The given number {number} is a prime number");
            else
                Console.WriteLine($"The given number {number} is not a prime number");
        }
        static Boolean isPrimeNumber(int number)
        {
            for (int counter = 2; counter <= number / 2; counter++)
            {
                if (number % counter == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}

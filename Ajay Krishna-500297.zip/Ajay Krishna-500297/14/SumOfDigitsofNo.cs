﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sumofdigit
{
    class SumOfDigitsofNo
    {
        static void Main(string[] args)
        {
            int number,num,digit,sum = 0;
            Console.WriteLine("Enter the digit to get summed");
            int.TryParse(Console.ReadLine(), out number);
            num = number;
            while (num > 0)
            {
                digit = num % 10;
                sum = sum + digit;
                num /= 10;
            }
            Console.WriteLine($"The given number is {number}");
            Console.WriteLine($"The sum of digit {number} is {sum}");
            Console.ReadKey();

        }
    }
}

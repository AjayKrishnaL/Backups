﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankaccount
{
    class Bank
    {

        public string name;
        public string accountnumber;
        public string accType;
        public double bal;
        public void intialValues()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("ENTER THE FOLLOWING VALUES: ");
            Console.ResetColor();
            Console.WriteLine("Enter the name of account holder");
            name = Console.ReadLine();
            if (!string.IsNullOrEmpty(name))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Enter a valid string");
                Console.ResetColor();
                name = Console.ReadLine();

            }
            accountnumber = genRandomnum();
            Console.WriteLine($"Your Account number is :{accountnumber}");
            Console.WriteLine("Enter the type of account");
            accType = Console.ReadLine();
            if (accType != "Savings" || accType != "Current")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Please enter a valid account type");
                Console.ResetColor();
                accType = Console.ReadLine();
            }
            Console.WriteLine("Enter the amount");
            bal = int.Parse(Console.ReadLine());
            displayName();
        }
        public void depositAmount()
        {

            Console.WriteLine("Please enter the account number to which the amount is to be deposited");
            string accnumber = Console.ReadLine();

            if (accnumber == accountnumber)
            {
                Console.WriteLine("Enter the amount to be deposited");
                bal = bal + double.Parse(Console.ReadLine());
            }

            else
            {
                Console.WriteLine("The account number is not invalid");

            }
            displayName();
            Console.ReadLine();
        }


        public void withdrawAmount()
        {

            Console.WriteLine("Please enter the account number to which the amount is to be deposited");
            string accnumber = Console.ReadLine();

            if (accnumber == accountnumber)
            {
                Console.WriteLine("Enter the amount to be withdrawn");
                double withamt = double.Parse(Console.ReadLine());
                if (bal > withamt)
                    bal = bal - withamt;
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Insufficient Balance.Please check the balance");
                    Console.ResetColor();
                }
            }

            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("The account number is not invalid");
                Console.ResetColor();
            }
            displayName();
            Console.ReadLine();
        }


        public void displayName()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"The bankacoount holder {name} maintaining the balance {bal}");
            Console.ResetColor();
        }
        string genRandomnum()
        {
            string accountNumber = "";
            Random random = new Random();
            string str = "";
            int i;
            for (i = 1; i < 13; i++)
            {
                str += random.Next(0, 9).ToString();
            }
            if (str.Length == 12)
            {
                accountNumber = str;

            }

            return accountNumber;

        }

    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankaccount
{
    class BankAccount
    {
        enum MainMethod
        {
            depositamount=1,withdrawamount=2
        }
        static void Main(string[] args)
        {

            Bank user1 = new Bank();
            user1.intialValues();
            DisplayMenu();
            Console.WriteLine("Choose the choice of operation");
            int choice = int.Parse(Console.ReadLine());
            switch ((MainMethod)choice)
            {
                case MainMethod.depositamount:
                    user1.depositAmount();
                    break;
                case MainMethod.withdrawamount:
                    user1.withdrawAmount();
                    break;
            }
        }

        static void DisplayMenu()
        {
            Console.WriteLine("Welcome to the Banking system");
            string[] menu =
            {
                "1.Deposit the amount",
                "2.Withdraw the amount"
            };

            for (int i = 0; i < menu.Length; i++)
            {
                Console.WriteLine(menu[i]);
            }
        }
    }

   
}


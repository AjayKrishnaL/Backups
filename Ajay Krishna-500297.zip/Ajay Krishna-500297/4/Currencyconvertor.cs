﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Currency_convertor
{
    class Currencyconvertor
    {
        delegate double mydelegate(double uSDollar);
        static void Main(string[] args)
        {
            
            double USDollar, IndianRupees, BritainPound;
            mydelegate del = rupeeCalculatar;
            mydelegate del1 = PoundCalculator;
            Console.WriteLine("Enter the US Dollar $ to find it's Britain and indian equivalent");
            double.TryParse(Console.ReadLine(), out USDollar);
            IndianRupees = del(USDollar);
            BritainPound = del1(USDollar);
            Console.WriteLine($"The rupee equivalent of ${USDollar} is INR{IndianRupees} only");
            Console.WriteLine($"The pound equivalent of ${USDollar} is PND{BritainPound} only");
            Console.ReadKey();
        }

        private static double PoundCalculator(double uSDollar)
        {
            double pound = uSDollar * 0.81;
            return pound;
        }

        private static double rupeeCalculatar(double uSDollar)
        {
            double rupee = uSDollar * 65.9949;
            return rupee;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DateTimeDemo
{
    class Date
    {
        static void Main(string[] args)
        {
            int year = int.Parse(Console.ReadLine());
            int month = int.Parse(Console.ReadLine());
            int day = int.Parse(Console.ReadLine());
            DateTime date = new DateTime(year,month,day);
            Console.WriteLine(date.ToString("dd'th' 'of' MMMM,yyyy"));
            Console.WriteLine($"Date and Time:  {date}");
            DateTime now = DateTime.Now;
            Console.WriteLine($"Date and Time:  {now}");
            int differenceInDays = (int)(now - date).TotalDays;
            Console.WriteLine($"Difference in days: {differenceInDays} ");
            Console.WriteLine($" difference in mintues : {(int)(now - date).TotalMinutes}");
            Console.WriteLine($" difference in seconds : {(long)(now - date).TotalSeconds}");
            Console.ReadLine(); 
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Factorialprogram
{
    class Factorial
    {
        static void Main(string[] args)
        {
            int counter, number, factorial = 1,factorial1;
            Console.WriteLine("Enter the number to find factorial:");
            int.TryParse(Console.ReadLine(),out number);
            if (number < 0)
            {
                Console.WriteLine("Given number is negative. Please Enter valid number");
            }
            else
            {
                for (counter = 1; counter <= number; counter++)
                {
                    factorial1 = factorial * counter;
                    Console.WriteLine($"Multiple of {factorial} * {counter} is {factorial1}");
                    factorial = factorial1;
                }
            }
            Console.WriteLine($"The Final Factorial is {factorial}");
            Console.ReadKey();
        }
    }
}

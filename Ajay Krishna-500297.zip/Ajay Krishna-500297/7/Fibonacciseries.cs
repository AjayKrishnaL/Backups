﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FibonacciSeries
{
    class Fibonacciseries
    {
        static void Main(string[] args)
        {
           int count, f1 = 0, f2 = 1, f3 = 0;
            Console.WriteLine("Enter the range of the fibonacci series");
            int.TryParse(Console.ReadLine(), out count);
            calfibonacci(f1,f2,f3,count);
            Console.ReadKey();
        }

        private static void calfibonacci(int f1, int f2, int f3, int count)
        {
            for (int i = 1; i <=count; i++)
            {
                Console.WriteLine(f1);
                f3 = f1 + f2;
                f1 = f2;
                f2 = f3;
            }
        }

    }
}

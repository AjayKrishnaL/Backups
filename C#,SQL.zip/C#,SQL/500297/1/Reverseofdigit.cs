﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reverseofadigit
{
    class Reverseofdigit
    {
        static void Main(string[] args)
        {
           Console.WriteLine("Enter the digit to be converted");
            string inputstring = Console.ReadLine();
            char[] charreverse = inputstring.ToCharArray();
            Array.Reverse(charreverse);
            string reverse = new string(charreverse);
            Console.WriteLine("Reverse of a digit is " + reverse);
            Console.ReadLine();
        }
    }
}

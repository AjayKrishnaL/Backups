﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PascalTriangle
{
    class PascalTriangle
    {
        static void Main(string[] args)
        {
            int number;
            Console.Write("Enter the number of rows: ");
            number = int.Parse(Console.ReadLine());
            for (int counter1 = 0; counter1 < number; counter1++)
            {
                int input = 1;
                for (int counter2 = 0; counter2< number - counter1; counter2++)
                {
                    Console.Write(" ");
                }
                for (int counter3 = 0; counter3 <= counter1; counter3++)
                {
                    Console.Write($" {input:D} ");
                    input = input * (counter1 - counter3) / (counter3 + 1);
                }
                Console.WriteLine();
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.ReadKey();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Shapes
{
    class areaofshapes
    {
        static void Main(string[] args)
        {
            Triangle triangle = new Triangle();
            Rectangle rectangle = new Rectangle();
            double number1, number2;
            set(out number1,out number2);
          double TArea=  triangle.Area(number1,number2);
           double RArea= rectangle.Area(number1,number2);
            displaymethod(TArea, RArea);
            Console.ReadKey();

        }

        private static void displaymethod(double Tarea, double rArea)
        {
            Console.WriteLine($"Area of Triangle is: {Tarea}");
            Console.WriteLine( $"Area of Rectangle is:{rArea}");
        }

        public static void set(out double number1,out double number2)
        {
            Console.WriteLine("Enter the length");
               number1=double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the breadth");
            number2 =double.Parse(Console.ReadLine());
          }
    }
   class Shapes
    {
      
       public virtual double Area(double number1, double number2)
        {
            return 0.0;
        }
       
    }
    class Triangle : Shapes
    {
        double breadth, height;
    
        public override double Area(double number1,double number2 )
        {
            breadth = number1;
            height = number2;
          double  Areaoftri = .5 * breadth * height;
            return Areaoftri;
        }
    }
    class Rectangle : Shapes
    {
        double length, height;
        public override double Area(double number1, double number2)
        {
            length = number1;
            height = number2;
            double AreaofRec = length * height;
            return AreaofRec;
        }
    }
}

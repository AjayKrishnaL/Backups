﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace _496498_HospitalManagementApp
{
    class InPatient : PatientDetails
    {
        List<InPatient> inPatientList = new List<InPatient>();
        DateTime admitDate;
        string disease;
        string test;

        public InPatient()
        {
        }

        public override string ToString()
        {
            return "Patient Name:" + PatientName + "\nAge:" + PatientAge + "\nDate Of Birth:" +
                PatientDOB.ToShortDateString() + "\nAddress:" + PatientAddress + "\nDoctor:" + ReferringDoctor +
                "\nAdmit Date:" + AdmitDate + "\nTest Name:" + Test;
        }
        public InPatient(string name, int id, DateTime dob, string address, string doctor, string test)
        {

            PatientName = name;
            PatIDStore = id;
            AdmitDate = DateTime.Now;
            PatientDOB = dob;
            PatientAge = AdmitDate.Year - PatientDOB.Year;
            PatientAddress = address;
            ReferringDoctor = doctor;

            Test = test;
        }
        public DateTime AdmitDate
        {
            get { return admitDate; }
            set { admitDate = value; }
        }

        public string Disease
        {
            get { return disease; }
            set { disease = value; }
        }

        public string Test
        {
            get
            { return test; }
            set { test = value; }
        }
        public int IsValid(string name)
        {
            Regex rgx = new Regex("^[a-zA-Z]+$");
            if (rgx.IsMatch(name))
                return 1;
            else
                return 0;
        }
        public int IsNumbers(string id)
        {
            Regex rgx = new Regex("^[0-9]+$");
            if (rgx.IsMatch(id))
                return 1;
            else
                return 0;
        }

        public override void GetPatientDetails()
        {
            int flag = 0;
            Console.WriteLine("Enter the Patient ID:");
            string ValidId = Console.ReadLine();
            int i = IsNumbers(ValidId);
            if (i == 1)
            {
                int idForDetails = Convert.ToInt32(ValidId);
                foreach (InPatient inPat in inPatientList)
                {
                    if (inPat.PatIDStore == idForDetails)
                    {
                        Console.WriteLine(inPat);
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("Not a valid id!");
                }
            }
            else

                Console.WriteLine("Not a valid id!");
        }


        public override void AddPatientDetails()
        {

            try
            {
                Console.WriteLine("Enter the patient name:");
                string pName = Console.ReadLine();
                int valid = IsValid(pName);
                if (valid == 1)
                {

                    Console.WriteLine("Enter the date of birth:");
                    DateTime pDob = Convert.ToDateTime(Console.ReadLine());
                    Console.WriteLine("Enter the address");
                    string pAddress = Console.ReadLine();
                    Console.WriteLine("Enter the refering doctor's name:");
                    string pRefDoc = Console.ReadLine();
                    int valid2 = IsValid(pRefDoc);
                    if (valid2 == 1)
                    {

                        Console.WriteLine("Enter test name:");
                        string pTest = Console.ReadLine();

                        int pID = ++PatientId;

                        inPatientList.Add(new InPatient(pName, pID, pDob, pAddress, pRefDoc, pTest));
                        Console.WriteLine("Patient details successfully saved with Id:{0}", pID);
                    }
                    else
                    {
                        Console.WriteLine("invalid input");
                    }
                }
                else
                {
                    Console.WriteLine("invalid input");
                }
            }
            catch
            {
                Console.WriteLine("Enter in mm/dd/yyyy format!");
            }
        }

        public override void RemovePatient()
        {
            int count = 0; int flag = 0;
            Console.WriteLine("Enter patient id:");
            string ValidId = Console.ReadLine();
            int y = IsNumbers(ValidId);
            if (y == 1)
            {
                int id = Convert.ToInt32(ValidId);

                foreach (InPatient i in inPatientList)
                {
                    if (i.PatientId == id)
                    {
                        inPatientList.RemoveAt(count);
                        flag = 1;
                        Console.WriteLine("Details removed");
                        break;
                    }
                    count++;
                }
                if (flag == 0)
                {
                    Console.WriteLine("Enter valid id!");
                }
            }
            else
            {
                Console.WriteLine("invalid id");
            }
        }
    }
}
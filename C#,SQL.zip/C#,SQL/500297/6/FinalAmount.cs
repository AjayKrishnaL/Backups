﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankdetails
{
    class FinalAmount
    {

        public static double rate;
        public static int days, year;
        public static double principleamount, interest, finalvalue;
        static void Main(string[] args)
        {
            int days,years,choice;
            Console.WriteLine("Enter the principle amount");
            double.TryParse(Console.ReadLine(), out principleamount);
            Console.WriteLine("Select whether your account is in day wise or year wise");
            int.TryParse(Console.ReadLine(), out choice);
            switch (choice)
            {
                case 1:
                    {
                       rate= daysRate();
                        days = returnDays();
                     finalvalue =calDaysRate(rate,days);
                        Console.WriteLine($"The Principle amount is {principleamount}");
                        Console.WriteLine($"The rate is {rate}");
                        Console.WriteLine($"The Period is {days} days");
                        Console.WriteLine($"The final value is {finalvalue}");
                        break;
                    }
                case 2:
                    {
                      rate=yearlyRate();
                        years = returnYear();
                     finalvalue=calYearlyRate(rate,years);
                        Console.WriteLine($"The Principle amount is {principleamount}");
                        Console.WriteLine($"The rate is {rate}");
                        Console.WriteLine($"The Period is {years} years");
                        Console.WriteLine($"The final value is {finalvalue}");
                        break;
                    }
                    
            }
            Console.ReadKey();   
        }

        private static double calYearlyRate(double rate, int years)
        {
            interest = principleamount * years * rate / 100;
            finalvalue = principleamount + interest;
            return finalvalue;
        }

        private static double calDaysRate(double rate, int days)
        {
            interest = principleamount * days * rate / (100*365);
            finalvalue = principleamount + interest;
            return finalvalue;
        }

       private static int returnDays()
        {
            return days;
        }

        private static double daysRate()
        {
            
            Console.WriteLine("Enter your days of creation of account");
            int.TryParse(Console.ReadLine(), out days);
            if (days < 7)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Minimum 7 days required to create an FD");
                Console.ResetColor();
               
            }
            else if (days >= 7 && days <= 60)
                return rate = 4.0;
            else if (days >= 61 && days <= 90)
                return rate = 4.50;
            else if (days >= 91 && days <= 179)
                return rate = 5.0;
            else if (days >= 180 && days <= 269)
                return rate = 5.75;
            else if (days >= 270 && days <= 364)
                return rate = 6.25;
            return 0;
        }

        private static double yearlyRate()
        {

            Console.WriteLine("Enter your years taken for creation of account");
            int.TryParse(Console.ReadLine(), out year);
            if (year == 1)
                return rate = 6.75;
            else if (year > 1 && year <= 2)
                return rate = 6.50;
            else if (year > 2 && year <= 3)
                return rate = 6.25;
            else if (year >= 3 && year <= 5)
                return rate = 6.0;
            else if (year > 5)
                return rate = 6.0;
            return 0;
        }
           public static int returnYear()
                {
            return year;
            }  
        }
    }



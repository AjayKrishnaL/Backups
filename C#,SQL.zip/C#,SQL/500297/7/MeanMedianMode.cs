﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MeanMedianMode
{
    class MeanMedianMode
    {
        static void Main(string[] args)
        {
            int number;
            float mean, median, standarddeviation;
            Console.Write("Enter the no to find mean median mode and standard deviation");
            number = int.Parse(Console.ReadLine());
            if (number < 3)
            {
                Console.WriteLine("The number of data points should be greater than 2.");

            }
            else
            {
                int[] arraynumber = new int[number];
                int i = 0;
                for (i = 0; i < number; i++)
                {
                    Console.Write("[{0}]:", i);
                    arraynumber[i] = int.Parse(Console.ReadLine());
                }

                bubblesort(arraynumber, number);

                int sum = 0;
                int j = 0;
                while (j < number)
                {
                    sum = sum + arraynumber[j];
                    j++;
                }

                mean = (float)sum / number;

                if (number % 2 != 0)
                    median = arraynumber[number / 2];
                else
                    median = (arraynumber[(number / 2) - 1] + arraynumber[number / 2]) / 2;


                int[,] mode = new int[number, 2];

                for (i = 0; i < 2; i++)
                    for (j = 0; j < number; j++)
                        mode[j, i] = 0;
                mode[0, 0] = 1;

                for (i = 0; i < number; i++)
                    for (j = 0; j < number - 1; j++)
                        if (arraynumber[i] == arraynumber[j + 1]) { ++mode[i, 0]; mode[i, 1] = arraynumber[i]; }

                int max;
                int k = 0;
                max = mode[0, 0];
                for (j = 0; j < number; j++)
                    if (max < mode[j, 0]) { max = mode[j, 0]; k = j; }

                float temp = 0.0f;

                for (j = 0; j < number; j++)
                {
                    temp = temp + (float)Math.Pow(arraynumber[j] - mean, 2);
                }

                standarddeviation = (float)Math.Sqrt(temp / (number - 1));

                Console.WriteLine("Mean Median Mode and Standard Deviation are as follows:");
                Console.WriteLine("..................................................");
                Console.WriteLine($"Arithmetic mean:{mean}");
                Console.WriteLine($"Median:{median}");
                if (mode[k, 1] != 0)
                    Console.WriteLine($"Mode:{mode[k, 1]}");
                else Console.WriteLine("Mode: no mode");
                Console.WriteLine($"Standard deviation:{standarddeviation}");


            }
            Console.ReadLine();
        }
        static void bubblesort(int[] arraynumber, int n)
        {
            int i, j;
            for (i = 0; i < n; i++)
                for (j = n - 1; j > i; j--)
                    if (arraynumber[j] < arraynumber[j - 1])
                    {
                        int temp = arraynumber[j];
                        arraynumber[j] = arraynumber[j - 1];
                        arraynumber[j - 1] = temp;
                    }

        }
    }
}

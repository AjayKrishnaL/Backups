﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sorting
{
    class Program
    {
        public static int[] arr;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the totel numbers");
            int num = int.Parse(Console.ReadLine());
            arr = new int[num];
            string[] menuOption = { "1. Ascending Order", "2. Descending Order" };
            foreach (var item in menuOption)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Enter your Choice");
            int choice = int.Parse(Console.ReadLine());

            
            Console.WriteLine("Enter numbers for array");
            for (int i = 0; i < num; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            switch (choice)
            {
                case 1:
                    bubbleSort(arr);
                    insertionSort(arr);
                    selectionSort(arr);
                  break;
                case 2:
                    bubbleSortd(arr);
                    insertionSortd(arr);
                    selectionSortd(arr);
                    break;
                default:
                    Console.WriteLine("Invalid Value");
                    break;
            }
            //time taken
            //number of operations done
            Console.ReadLine();
        }



        private static void insertionSort(int[] arr)
        {

            
                int n = arr.Length;
                for (int j = 1; j < n; j++)
                {
                    int key = arr[j];
                    int i = j - 1;
                    while ((i > -1) && (arr[i] > key))
                    {
                        arr[i + 1] = arr[i];
                        i--;
                    }
                    arr[i + 1] = key;
                }
            
            Console.WriteLine("The Sorted Array using insertion sort is :");
            for (int i = 0; i < arr.Length; i++)
                Console.WriteLine(arr[i]);
        }

        private static void insertionSortd(int[] arr)
        {
            for (int i = 1; i > arr.Length; i++)
            {
                int item = arr[i];
                int ins = 0;
                for (int j = i - 1; j >= 0 && ins != 1;)
                {
                    if (item < arr[j])
                    {
                        arr[j + 1] = arr[j];
                        j--;
                        arr[j + 1] = item;
                    }
                    else ins = 1;
                }
            }

            Console.WriteLine("The array after Insertion sort:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);

            }
        }

        private static void bubbleSort(int[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                for (int j = 0; j <= i - 1; j++)
                {
                    if (arr[j] > arr[j + 1])
                    {
                        int temp = arr[j];

                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
            Console.WriteLine("The array after Bubble sort:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);

            }
        }
        private static void bubbleSortd(int[] arr)
        {
            for (int i = arr.Length - 1; i > 0; i--)
            {
                for (int j = 0; j <= i - 1; j++)
                {
                    if (arr[j] < arr[j + 1])
                    {
                        int temp = arr[j];

                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
            Console.WriteLine("The array after Bubble sort:");

            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);

            }
        }
        private static void selectionSort(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
            int tmp, min_key;

            for (int j = 0; j < arr.Length - 1; j++)
            {
                min_key = j;

                for (int k = j + 1; k < arr.Length; k++)
                {
                    if (arr[k] < arr[min_key])
                    {
                        min_key = k;
                    }
                }

                tmp = arr[min_key];
                arr[min_key] = arr[j];
                arr[j] = tmp;
            }

            Console.WriteLine("The Array After Selection Sort is: ");
            for (int i = 0; i <  arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }

        private static void selectionSortd(int[] arr)
        {
            for (int i = 0; i < arr.Length; ++i)
            {
                for (int j = i + 1; j < arr.Length; ++j)
                {
                    if (arr[i] < arr[j])
                    {
                        int temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            Console.WriteLine("Selection Sorting in descending order");
            for (int i = 0; i < arr.Length; ++i)
            {
                Console.WriteLine(arr[i]);
            }
        }
        
    }
    }



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankAccounts
{
    public class BankAccount
    {
        static List<Account> Accounts = new List<Account>();
        static void Main(string[] args)
        {
            ShowMenu();
            Console.ReadKey();
        }

        public static void OpenAccount()
        {
            Account account = Account.OpenAccount();
            Accounts.Add(account);
            Console.WriteLine("Account Created Successfully..!");
            Console.WriteLine("Your Account Number : " + account.AccountNumber); 
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
            ShowMenu();
        }

        public static void EditAccount()
        {
            Account account = Account.EditAccount(Accounts);
            if (account != null)
            {
                Console.Clear();
                Console.WriteLine("Your Updated Account Details");
                Console.WriteLine("Account Number : " + account.AccountNumber);
                Console.WriteLine("User Name : " + account.UserName);
                Console.WriteLine("Balance : " + account.Balance);
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                ShowMenu();
            }
            else
            {
                ShowMenu();
            }
        }

        public static void GetAccountDetails()
        {
        Start:
            Console.Clear();
            Console.WriteLine("\t Account Detils");
            Console.WriteLine("\t ==============");
            Account HisAccount = null;
            if (Accounts.Count > 0)
            {
                bool NotExist = true;
                Console.Write("Please Enter Your Account Number : ");
                Int64 accNumber = Convert.ToInt64(Console.ReadLine());
                foreach (Account acc in Accounts)
                {
                    if (acc.AccountNumber == accNumber)
                    {
                        NotExist = false;
                        HisAccount = acc;
                        break;
                    }
                }
                if (NotExist)
                {
                    Console.WriteLine("This Account Number Doesn't Exist in Our System. Press any key to continue");
                    Console.ReadKey();
                    goto Start;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Your Account Details");
                    Console.WriteLine("Account Number : " + HisAccount.AccountNumber);
                    Console.WriteLine("User Name : " + HisAccount.UserName);
                    Console.WriteLine("Balance : " + HisAccount.Balance);
                    Console.WriteLine("Press any key to continue...");
                    Console.ReadKey();
                    ShowMenu();
                }
            }
            else
            {
                Console.WriteLine("There is no Account Available in Our System. Press any key to continue...");
                Console.ReadKey();
                ShowMenu();
            }
        }

        public static void ShowMenu()
        {
            Console.Clear();

            Console.WriteLine("\t\tCaselet On Bank Acounts");
            Console.WriteLine("\t\t=======================");
            Console.WriteLine("\t 1. Open Account");
            Console.WriteLine("\t 2. Edit Account");
            Console.WriteLine("\t 3. Get Account Details");
            Console.WriteLine("\t 4. Exit");
            Menu:
            Console.Write("Enter Your Choice : ");
            
            try
            {
                int ch = Convert.ToInt32(Console.ReadLine());
                if (ch == 0 || ch > 4)
                {
                    Console.WriteLine("Invalid Selection");
                    goto Menu;
                }
                switch (ch)
                {
                    case 1:
                        OpenAccount();
                        break;
                    case 2:
                        EditAccount();
                        break;
                    case 3:
                        GetAccountDetails();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                }
            }
            catch (FormatException ex)
            {
                Console.WriteLine("Exception: Please Enter Valid Number");
                goto Menu;
            }
        }
    }
}
